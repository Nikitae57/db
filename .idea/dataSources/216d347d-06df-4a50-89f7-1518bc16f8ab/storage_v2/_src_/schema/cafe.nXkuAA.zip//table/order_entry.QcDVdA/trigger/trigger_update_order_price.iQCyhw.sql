create trigger trigger_update_order_price
  before INSERT
  on order_entry
  for each row
BEGIN
  DECLARE meal_price INT;

  SET meal_price = (SELECT meal.price FROM meal WHERE meal.id = NEW.meal_id LIMIT 1);
  SET NEW.price = meal_price * NEW.amount;

  UPDATE `order`
  SET `order`.price = `order`.price + NEW.price
    WHERE `order`.id = NEW.order_id;
END;

