create trigger trigger_update_discount_state_for_order
  before INSERT
  on `order`
  for each row
BEGIN
  SET NEW.discount_id = (SELECT id FROM discount
    WHERE discount.finish_time >= CURDATE()
          AND discount.start_time <= CURDATE() LIMIT 1);
END;

