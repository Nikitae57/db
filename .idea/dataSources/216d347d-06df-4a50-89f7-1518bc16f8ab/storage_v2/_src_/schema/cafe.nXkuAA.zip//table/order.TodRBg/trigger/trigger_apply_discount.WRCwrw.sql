create trigger trigger_apply_discount
  before UPDATE
  on `order`
  for each row
this_trigger:BEGIN
  DECLARE usual_discount INT;
  DECLARE card_discount INT;
  DECLARE order_entries_count INT;

  IF NEW.is_paid = TRUE AND OLD.is_paid = FALSE THEN
    IF NEW.discount_id IS NOT NULL AND NEW.discount_card_id IS NULL THEN
      SET usual_discount = (SELECT discount.amount FROM discount
        WHERE discount.id = NEW.discount_id LIMIT 1);

      SET NEW.price = CEIL(OLD.price * (100 - usual_discount)/100);


    ELSEIF NEW.discount_card_id IS NOT NULL THEN
      SET order_entries_count = (SELECT COUNT(id) FROM order_entry WHERE order_entry.order_id = NEW.id);

      IF order_entries_count <= 5 THEN
        SET card_discount = 5;
      ELSEIF order_entries_count <= 10 AND order_entries_count > 5 THEN
        SET card_discount = 10;
      ELSEIF order_entries_count > 10 THEN
        SET card_discount = 15;
      END IF;

      IF NEW.discount_id IS NULL OR usual_discount < card_discount THEN
        UPDATE `order`
          SET NEW.price = CEIL(OLD.price * (100 - card_discount)/10);
      ELSE
        SET usual_discount = (SELECT discount.amount FROM discount
          WHERE discount.id = NEW.discount_id LIMIT 1);

        UPDATE `order`
          SET NEW.price = CEIL(OLD.price * (100 - usual_discount)/100);
      END IF;
    END IF;
  END IF;
END;

