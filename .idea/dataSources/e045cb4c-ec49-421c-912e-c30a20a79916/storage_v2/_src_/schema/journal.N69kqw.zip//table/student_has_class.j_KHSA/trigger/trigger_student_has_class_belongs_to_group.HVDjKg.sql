create trigger trigger_student_has_class_belongs_to_group
  before INSERT
  on student_has_class
  for each row
BEGIN
  DECLARE student_group_id INT;
  DECLARE class_group_id INT;

  SET student_group_id = 
    (SELECT group_id FROM student WHERE student.id = NEW.student_id LIMIT 1);
  
  SET class_group_id =
      (SELECT class.group_has_type_subject_teacher_group_id FROM class WHERE class.id = NEW.class_id LIMIT 1);
      

  IF student_group_id = class_group_id THEN
    SET @student_id = NEW.student_id;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Студент не принадлежит этой группе';
  END IF;
END;

