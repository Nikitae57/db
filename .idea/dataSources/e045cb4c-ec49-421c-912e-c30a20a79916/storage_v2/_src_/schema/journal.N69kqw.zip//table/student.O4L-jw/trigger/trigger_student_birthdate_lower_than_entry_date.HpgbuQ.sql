create trigger trigger_student_birthdate_lower_than_entry_date
  before INSERT
  on student
  for each row
BEGIN
  IF NEW.birthDate < NEW.entryDate THEN
    SET @birhdate = NEW.birthDate;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Родился позже, чем поступил?';
  END IF;
END;

