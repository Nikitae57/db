create procedure nothing_in_nothing_out()
BEGIN
  SELECT id, student.lastname, student.firstname, student.midname FROM student;
  SELECT group_id FROM student;
END;

