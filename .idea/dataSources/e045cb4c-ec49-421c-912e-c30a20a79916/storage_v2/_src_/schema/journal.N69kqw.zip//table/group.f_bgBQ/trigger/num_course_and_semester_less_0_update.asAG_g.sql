create trigger num_course_and_semester_less_0_update
  before UPDATE
  on `group`
  for each row
BEGIN
  IF NEW.course > 0 THEN
    SET @course = NEW.course;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Курс группы должен быть больше 0';
  end if;

  IF NEW.semester > 0 THEN
    SET @semester = NEW.semester;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Семестр группы должен быть больше 0';
  end if;
END;

