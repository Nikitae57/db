create trigger num_hours_subject_less_0_update
  before UPDATE
  on group_has_type_subject_teacher
  for each row
BEGIN
  IF NEW.hours_number > 0 THEN
    SET @hours_number = NEW.hours_number;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Кол-во часов должно быть больше 0';
  end if;
END;

