create trigger trigger_student_name
  before INSERT
  on student
  for each row
BEGIN
  IF NEW.firstname REGEXP '[А-Яа-я]' != '' THEN
    SET @firstname := NEW.firstname;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Только русские буквы';
  END IF;

  IF NEW.lastname REGEXP '[А-Яа-я]' != '' THEN
    SET @lastname := NEW.lastname;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Только русские буквы';
  END IF;

  IF NEW.midname REGEXP '[А-Яа-я]' != '' THEN
    SET @midname := NEW.midname;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Только русские буквы';
  END IF;
END;

