create function nothing_in_something_out() returns varchar(45)
BEGIN
  RETURN (SELECT student.firstname FROM student WHERE student.id = 170576 LIMIT 1);
END;

