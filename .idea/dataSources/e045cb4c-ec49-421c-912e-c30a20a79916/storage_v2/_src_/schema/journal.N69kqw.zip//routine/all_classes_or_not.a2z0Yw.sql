create function all_classes_or_not(group_name varchar(45), subject_name varchar(45)) returns tinyint(1)
BEGIN
  DECLARE lec_hours_expected INT;
  DECLARE prac_hours_expected INT;
  DECLARE lab_hours_expected INT;

  DECLARE lec_hours_were INT;
  DECLARE prac_hours_were INT;
  DECLARE lab_hours_were INT;

  DECLARE group_id INT;
  DECLARE subject_id INT;

  DECLARE lec_id INT;
  DECLARE prac_id INT;
  DECLARE lab_id INT;

  DECLARE all_labs_were BOOL;
  DECLARE all_pracs_were BOOL;
  DECLARE all_lecs_were BOOL;

  SET group_id = (SELECT id FROM `group` WHERE groupName = group_name LIMIT 1);
  SET subject_id = (SELECT id FROM subject WHERE subject.name = subject_name LIMIT 1);

  SET lec_id = (SELECT id FROM class_type WHERE type_name = 'Лекция' LIMIT 1);
  SET prac_id = (SELECT id FROM class_type WHERE type_name = 'Практическая работа' LIMIT 1);
  SET lab_id = (SELECT id FROM class_type WHERE type_name = 'Лабораторная работа' LIMIT 1);

  SET lec_hours_expected =
    (SELECT hours_number FROM group_has_type_subject_teacher
      WHERE group_has_type_subject_teacher.group_id = group_id
      AND group_has_type_subject_teacher.subject_id = subject_id
      AND group_has_type_subject_teacher.class_type_id = lec_id LIMIT 1);

  SET prac_hours_expected =
    (SELECT hours_number FROM group_has_type_subject_teacher
      WHERE group_has_type_subject_teacher.group_id = group_id
      AND group_has_type_subject_teacher.subject_id = subject_id
      AND group_has_type_subject_teacher.class_type_id = prac_id LIMIT 1);

  SET lab_hours_expected =
    (SELECT hours_number FROM group_has_type_subject_teacher
      WHERE group_has_type_subject_teacher.group_id = group_id
      AND group_has_type_subject_teacher.subject_id = subject_id
      AND group_has_type_subject_teacher.class_type_id = lab_id LIMIT 1);

  SET lec_hours_were =
      (SELECT (COUNT(id) * 2) FROM class
        WHERE class.group_has_type_subject_teacher_subject_id = subject_id
        AND class.group_has_type_subject_teacher_class_type_id = lec_id
        AND class.group_has_type_subject_teacher_group_id = group_id
        GROUP BY (group_id) LIMIT 1
      );

  SET prac_hours_were =
      (SELECT (COUNT(id) * 2) FROM class
        WHERE class.group_has_type_subject_teacher_subject_id = subject_id
        AND class.group_has_type_subject_teacher_class_type_id = prac_id
        AND class.group_has_type_subject_teacher_group_id = group_id
        GROUP BY (group_id) LIMIT 1
      );

  SET lab_hours_were =
      (SELECT (COUNT(id) * 4) FROM class
        WHERE class.group_has_type_subject_teacher_subject_id = subject_id
        AND class.group_has_type_subject_teacher_class_type_id = lab_id
        AND class.group_has_type_subject_teacher_group_id = group_id
        GROUP BY (group_id) LIMIT 1
      );

  IF lab_hours_were < lab_hours_expected THEN
    SET all_labs_were = FALSE;
  ELSE
    SET all_labs_were = TRUE;
  end if;

  IF lec_hours_were < lec_hours_expected THEN
    SET all_lecs_were = FALSE;
  ELSE
    SET all_lecs_were = TRUE;
  end if;

  IF prac_hours_were < prac_hours_expected THEN
    SET all_pracs_were = FALSE;
  ELSE
    SET all_pracs_were = TRUE;
  end if;

  RETURN all_pracs_were AND all_labs_were AND all_lecs_were;
END;

