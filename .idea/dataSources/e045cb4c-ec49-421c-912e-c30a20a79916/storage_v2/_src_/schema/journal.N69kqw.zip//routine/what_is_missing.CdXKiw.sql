create procedure what_is_missing(IN group_name varchar(45), IN subject_name varchar(45))
BEGIN
  DECLARE lec_hours_expected INT;
  DECLARE prac_hours_expected INT;
  DECLARE lab_hours_expected INT;

  DECLARE lec_hours_were INT;
  DECLARE prac_hours_were INT;
  DECLARE lab_hours_were INT;

  DECLARE group_id INT;
  DECLARE subject_id INT;

  DECLARE lec_id INT;
  DECLARE prac_id INT;
  DECLARE lab_id INT;

  DECLARE labs_hours_missing INT;
  DECLARE lecs_hours_missing INT;
  DECLARE pracs_hours_missing INT;

  SET group_id = (SELECT id FROM `group` WHERE groupName = group_name LIMIT 1);
  SET subject_id = (SELECT id FROM subject WHERE subject.name = subject_name LIMIT 1);

  SET lec_id = (SELECT id FROM class_type WHERE type_name = 'Лекция' LIMIT 1);
  SET prac_id = (SELECT id FROM class_type WHERE type_name = 'Практическая работа' LIMIT 1);
  SET lab_id = (SELECT id FROM class_type WHERE type_name = 'Лабораторная работа' LIMIT 1);

  SET lec_hours_expected =
    (SELECT hours_number FROM group_has_type_subject_teacher
      WHERE group_has_type_subject_teacher.group_id = group_id
      AND group_has_type_subject_teacher.subject_id = subject_id
      AND group_has_type_subject_teacher.class_type_id = lec_id LIMIT 1);

  SET prac_hours_expected =
    (SELECT hours_number FROM group_has_type_subject_teacher
      WHERE group_has_type_subject_teacher.group_id = group_id
      AND group_has_type_subject_teacher.subject_id = subject_id
      AND group_has_type_subject_teacher.class_type_id = prac_id LIMIT 1);

  SET lab_hours_expected =
    (SELECT hours_number FROM group_has_type_subject_teacher
      WHERE group_has_type_subject_teacher.group_id = group_id
      AND group_has_type_subject_teacher.subject_id = subject_id
      AND group_has_type_subject_teacher.class_type_id = lab_id LIMIT 1);

  SET lec_hours_were =
      (SELECT (COUNT(id) * 2) FROM class
        WHERE class.group_has_type_subject_teacher_subject_id = subject_id
        AND class.group_has_type_subject_teacher_class_type_id = lec_id
        AND class.group_has_type_subject_teacher_group_id = group_id
        GROUP BY (group_id) LIMIT 1
      );

  SET prac_hours_were =
      (SELECT (COUNT(id) * 2) FROM class
        WHERE class.group_has_type_subject_teacher_subject_id = subject_id
        AND class.group_has_type_subject_teacher_class_type_id = prac_id
        AND class.group_has_type_subject_teacher_group_id = group_id
        GROUP BY (group_id) LIMIT 1
      );

  SET lab_hours_were =
      (SELECT (COUNT(id) * 4) FROM class
        WHERE class.group_has_type_subject_teacher_subject_id = subject_id
        AND class.group_has_type_subject_teacher_class_type_id = lab_id
        AND class.group_has_type_subject_teacher_group_id = group_id
        GROUP BY (group_id) LIMIT 1
      );

  IF lab_hours_were IS NULL THEN
    SET lab_hours_were = 0;
  end if;

  IF prac_hours_were IS NULL THEN
    SET prac_hours_were = 0;
  end if;

  IF lec_hours_were IS NULL THEN
    SET lec_hours_were = 0;
  end if;

  IF lab_hours_were < lab_hours_expected THEN
    SET labs_hours_missing = lab_hours_expected - lab_hours_were;
  ELSE
    SET labs_hours_missing = 0;
  end if;

  IF lec_hours_were < lec_hours_expected THEN
    SET lecs_hours_missing = lec_hours_expected - lec_hours_were;
  ELSE
    SET lecs_hours_missing = 0;
  end if;

  IF prac_hours_were < prac_hours_expected THEN
    SET pracs_hours_missing = prac_hours_expected - prac_hours_were;
  ELSE
    SET pracs_hours_missing = 0;
  end if;

  SELECT labs_hours_missing, lecs_hours_missing, pracs_hours_missing;

END;

