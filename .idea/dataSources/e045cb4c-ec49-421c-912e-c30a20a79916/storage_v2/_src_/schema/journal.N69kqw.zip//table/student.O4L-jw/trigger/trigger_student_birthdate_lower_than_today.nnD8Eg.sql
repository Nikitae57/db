create trigger trigger_student_birthdate_lower_than_today
  before INSERT
  on student
  for each row
BEGIN
  DECLARE curr_date DATE;
  SET curr_date = CURDATE();

  IF NEW.birthDate < curr_date THEN
    SET @birhdate = NEW.birthDate;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Родился позже, чем сегодня?';
  end if;
END;

