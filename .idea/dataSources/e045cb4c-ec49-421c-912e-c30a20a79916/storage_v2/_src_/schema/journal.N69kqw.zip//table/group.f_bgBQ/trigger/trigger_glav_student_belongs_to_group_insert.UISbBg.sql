create trigger trigger_glav_student_belongs_to_group_insert
  before UPDATE
  on `group`
  for each row
BEGIN
  DECLARE student_group_id INT;

  SET student_group_id = (SELECT student.group_id FROM student WHERE student.id = NEW.student_id);

  IF student_group_id = id THEN
    SET @student_id = NEW.student_id;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Староста не из этой группы';
  END IF;
END;

