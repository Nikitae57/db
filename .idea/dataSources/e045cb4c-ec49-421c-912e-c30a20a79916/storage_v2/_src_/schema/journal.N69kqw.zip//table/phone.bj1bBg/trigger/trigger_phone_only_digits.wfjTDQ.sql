create trigger trigger_phone_only_digits
  before INSERT
  on phone
  for each row
BEGIN
  IF NEW.number REGEXP '^[0-9]+$' THEN
    SET @number = NEW.number;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Телефон может состоять только из цифр';
  END IF ;
END;

