create procedure something_in_nothing_out(IN _id int)
BEGIN
  SELECT student.lastname, student.firstname, student.midname FROM student WHERE student.id = _id;
END;

