create trigger trigger_student_entrydate_lower_than_today
  before INSERT
  on student
  for each row
BEGIN
  DECLARE curr_date DATE;
  SET curr_date = CURDATE();

  IF NEW.entryDate < curr_date THEN
    SET @entryDate= NEW.entryDate;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Поступил позже, чем сегодня?';
  end if;
END;

