create function something_in_something_out(_id int) returns varchar(45)
BEGIN
  return (SELECT student.midname FROM student WHERE student.id = _id LIMIT 1);
END;

